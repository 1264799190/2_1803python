from distutils.core import setup
setup(name="xiaowang", version="1.0", description="xiaowang's module", author="xiaowang", py_modules=['send','recv'])
